// Keep all existing Firebase configuration and initialization

// New Global Variables
let userLocation = null;
let userPreferences = {
    viewedProducts: [],
    purchasedProducts: [],
    favoriteCategories: []
};

// Enhanced Product Structure
const sampleProduct = {
    id: "prod123",
    name: "Bidhaa Sample",
    description: "Maelezo ya bidhaa",
    price: 15000,
    category: "electronics",
    stock: 10,
    imageUrl: "https://via.placeholder.com/300",
    sellerId: "seller123",
    sellerLocation: "Dar es Salaam",
    sellerCoords: { lat: -6.7924, lng: 39.2083 },
    deliveryTime: 45, // in minutes
    rating: 4.5,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
};

// Location Services
function requestLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => {
                userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                document.getElementById('locationBanner').style.display = 'none';
                updateUIWithLocation();
                loadNearbyBusinesses();
                loadRecommendedProducts();
            },
            error => {
                console.error("Error getting location:", error);
                document.getElementById('locationBanner').querySelector('p').textContent = 
                    "Hatuwezi kupata eneo lako. Tafadhali hakikisha umeruhusu upatikanaji wa eneo.";
            }
        );
    } else {
        alert("Kivinjari chako hakitumii huduma ya eneo.");
    }
}

function updateUIWithLocation() {
    if (userLocation) {
        // Reverse geocode to get location name (simplified)
        const locationText = "Karibu nawe"; // In a real app, use Google Maps API or similar
        document.getElementById('currentLocationText').textContent = locationText;
        document.getElementById('userLocationBadge').style.display = 'inline-flex';
    }
}

// Nearby Businesses
async function loadNearbyBusinesses() {
    if (!userLocation) return;
    
    try {
        const businesses = await db.collection('businesses')
            .where('location', '==', 'Dar es Salaam') // Simplified - should use geoqueries
            .limit(10)
            .get();
        
        const nearbyBusinesses = businesses.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        
        displayNearbyBusinesses(nearbyBusinesses);
    } catch (error) {
        console.error("Error loading businesses:", error);
    }
}

function displayNearbyBusinesses(businesses) {
    const grid = document.getElementById('nearbyBusinesses');
    
    if (businesses.length === 0) {
        grid.innerHTML = '<div class="loading">Hakuna maduka ya karibu yanayopatikana</div>';
        return;
    }
    
    grid.innerHTML = businesses.map(business => {
        // Calculate distance (simplified)
        const distance = userLocation ? 
            Math.round(geolib.getDistance(
                { latitude: userLocation.lat, longitude: userLocation.lng },
                { latitude: business.lat, longitude: business.lng }
            ) / 1000) : '?';
        
        return `
            <div class="business-card fade-in">
                <img src="${business.imageUrl || 'https://via.placeholder.com/300'}" 
                     alt="${business.name}" class="business-image">
                <div class="business-info">
                    <div class="business-name">${business.name}</div>
                    <div class="business-distance">${distance} km kutoka kwako</div>
                    <div class="business-rating">
                        ${'★'.repeat(Math.round(business.rating || 0))}${'☆'.repeat(5 - Math.round(business.rating || 0))}
                        (${business.reviewCount || 0})
                    </div>
                    <div class="business-delivery-time">
                        <i class="fas fa-clock"></i> Muda wa kufikisha: ${business.deliveryTime || '?'} dakika
                    </div>
                    <button class="btn btn-secondary" style="width:100%; margin-top:10px;" 
                            onclick="showBusinessProducts('${business.id}')">
                        <i class="fas fa-store"></i> Angalia Bidhaa
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// Personalized Recommendations
async function loadRecommendedProducts() {
    if (!currentUser) return;
    
    try {
        // Get user preferences
        const userDoc = await db.collection('users').doc(currentUser.uid).get();
        if (userDoc.exists) {
            userPreferences = {
                ...userPreferences,
                ...userDoc.data().preferences
            };
        }
        
        // Simple recommendation logic - in a real app, use more sophisticated algorithms
        let query = db.collection('products')
            .orderBy('createdAt', 'desc')
            .limit(10);
        
        if (userPreferences.favoriteCategories && userPreferences.favoriteCategories.length > 0) {
            query = query.where('category', 'in', userPreferences.favoriteCategories.slice(0, 3));
        }
        
        const snapshot = await query.get();
        const recommendedProducts = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        
        displayRecommendedProducts(recommendedProducts);
        document.getElementById('personalizedSection').style.display = 'block';
    } catch (error) {
        console.error("Error loading recommendations:", error);
    }
}

function displayRecommendedProducts(products) {
    const grid = document.getElementById('recommendedProducts');
    
    if (products.length === 0) {
        grid.innerHTML = '<div class="loading">Hakuna mapendekezo kwa sasa</div>';
        return;
    }
    
    grid.innerHTML = products.map(product => `
        <div class="product-card fade-in" onclick="showProductDetails('${product.id}')">
            <div class="recommended-badge"><i class="fas fa-heart"></i> Pendekezo</div>
            <img src="${product.imageUrl}" alt="${product.name}" class="product-image">
            <div class="product-info">
                <div class="product-title">${product.name}</div>
                <div class="product-price">TSH ${product.price.toLocaleString()}</div>
                <div class="product-location">📍 ${product.sellerLocation}</div>
            </div>
        </div>
    `).join('');
}

// Enhanced Search with Suggestions
document.getElementById('searchInput').addEventListener('input', async function(e) {
    const query = e.target.value.trim();
    const suggestionsDiv = document.getElementById('searchSuggestions');
    
    if (query.length < 2) {
        suggestionsDiv.style.display = 'none';
        return;
    }
    
    try {
        // Search products
        const productsSnapshot = await db.collection('products')
            .orderBy('name')
            .startAt(query)
            .endAt(query + '\uf8ff')
            .limit(5)
            .get();
        
        // Search businesses
        const businessesSnapshot = await db.collection('businesses')
            .orderBy('name')
            .startAt(query)
            .endAt(query + '\uf8ff')
            .limit(5)
            .get();
        
        const suggestions = [
            ...productsSnapshot.docs.map(doc => ({
                type: 'product',
                id: doc.id,
                name: doc.data().name,
                category: doc.data().category
            })),
            ...businessesSnapshot.docs.map(doc => ({
                type: 'business',
                id: doc.id,
                name: doc.data().name,
                category: doc.data().category
            }))
        ];
        
        if (suggestions.length > 0) {
            suggestionsDiv.innerHTML = suggestions.map(item => `
                <div onclick="selectSuggestion('${item.type}', '${item.id}')">
                    ${item.name} <small>(${getCategoryName(item.category)})</small>
                </div>
            `).join('');
            suggestionsDiv.style.display = 'block';
        } else {
            suggestionsDiv.style.display = 'none';
        }
    } catch (error) {
        console.error("Error fetching suggestions:", error);
    }
});

function selectSuggestion(type, id) {
    if (type === 'product') {
        showProductDetails(id);
    } else if (type === 'business') {
        showBusinessProducts(id);
    }
    document.getElementById('searchInput').value = '';
    document.getElementById('searchSuggestions').style.display = 'none';
}

// Enhanced Filtering
function filterProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const categoryFilter = document.getElementById('categoryFilter').value;
    const distanceFilter = parseInt(document.getElementById('distanceFilter').value);
    const deliveryFilter = parseInt(document.getElementById('deliveryFilter').value);
    const ratingFilter = parseInt(document.getElementById('ratingFilter').value);
    
    const filteredProducts = allProducts.filter(product => {
        // Search term
        const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                            product.description.toLowerCase().includes(searchTerm);
        
        // Category
        const matchesCategory = !categoryFilter || product.category === categoryFilter;
        
        // Distance (simplified - should use actual distance calculation)
        let matchesDistance = true;
        if (distanceFilter && userLocation && product.sellerCoords) {
            const distance = geolib.getDistance(
                { latitude: userLocation.lat, longitude: userLocation.lng },
                { latitude: product.sellerCoords.lat, longitude: product.sellerCoords.lng }
            ) / 1000; // Convert to km
            matchesDistance = distance <= distanceFilter;
        }
        
        // Delivery time
        const matchesDelivery = !deliveryFilter || (product.deliveryTime && product.deliveryTime <= deliveryFilter);
        
        // Rating
        const matchesRating = !ratingFilter || (product.rating && product.rating >= ratingFilter);
        
        return matchesSearch && matchesCategory && matchesDistance && matchesDelivery && matchesRating;
    });
    
    displayProducts(filteredProducts);
}

// Track user behavior for recommendations
function trackProductView(productId) {
    if (!currentUser) return;
    
    // Add to viewed products if not already there
    if (!userPreferences.viewedProducts.includes(productId)) {
        userPreferences.viewedProducts.push(productId);
        
        // Update favorite categories based on views
        const product = allProducts.find(p => p.id === productId);
        if (product && !userPreferences.favoriteCategories.includes(product.category)) {
            userPreferences.favoriteCategories.push(product.category);
        }
        
        // Update in Firestore
        db.collection('users').doc(currentUser.uid).update({
            'preferences.viewedProducts': userPreferences.viewedProducts,
            'preferences.favoriteCategories': userPreferences.favoriteCategories
        });
    }
}

// Modify showProductDetails to track views
async function showProductDetails(productId) {
    trackProductView(productId);
    // ... rest of your existing showProductDetails code ...
       const product = allProducts.find(p => p.id === productId);
    if (!product) return;
    
    // Get seller info
    const sellerDoc = await db.collection('users').doc(product.sellerId).get();
    const seller = sellerDoc.data();
    
    document.getElementById('productDetails').innerHTML = `
        <h2>${product.name}</h2>
        <img src="${product.imageUrl}" alt="${product.name}" style="width: 100%; max-height: 300px; object-fit: cover; border-radius: 10px; margin-bottom: 20px;">
        <div style="font-size: 24px; font-weight: bold; color: #667eea; margin-bottom: 15px;">
            TSH ${product.price.toLocaleString()}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Maelezo:</strong><br>
            ${product.description}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Aina:</strong> ${getCategoryName(product.category)}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Idadi Iliyopo:</strong> ${product.stock}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Eneo:</strong> ${product.sellerLocation}
        </div>
        <div style="margin-bottom: 20px;">
            <strong>Muuzaji:</strong> ${seller.firstName} ${seller.lastName}<br>
            <strong>Simu:</strong> ${seller.phone}
        </div>
        ${currentUser && currentUser.userType === 'customer' ? `
            <button class="btn btn-primary" onclick="orderProduct('${product.id}')" style="width: 100%;">
                Agiza Bidhaa Hii
            </button>
        ` : ''}
    `;
    
    document.getElementById('productModal').style.display = 'block';

}

// Initialize app with location request
document.addEventListener('DOMContentLoaded', function() {
    // Show location banner if permission not granted
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => {
                userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                updateUIWithLocation();
                loadNearbyBusinesses();
            },
            () => {
                document.getElementById('locationBanner').style.display = 'flex';
            }
        );
    }
    
    loadProducts();
});