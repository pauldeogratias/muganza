


// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBfx2U6d3EFfDBTdr6VPVXtWsDLElNSPmA",
    authDomain: "biashara-37163.firebaseapp.com",
    projectId: "biashara-37163",
    storageBucket: "biashara-37163.firebasestorage.app",
    messagingSenderId: "94176136097",
    appId: "1:94176136097:web:0b98048c135e3e0f61d9e0",
    measurementId: "G-36M6ZY7SZM"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();

// Global variables
let currentUser = null;
let allProducts = [];

// Show/Hide sections
function showSection(sectionName) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');
    
    if (sectionName === 'products') {
        loadProducts();
    }
}

// Modal functions
function showLogin() {
    document.getElementById('loginModal').style.display = 'block';
}

function showRegister() {
    document.getElementById('registerModal').style.display = 'block';
}

function showAddProduct() {
    document.getElementById('addProductModal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Upload image to CDN
async function uploadImageToCDN(imageFile) {
    const formData = new FormData();
    formData.append('image', imageFile);
    
    try {
        // Using ImgBB free CDN service
        const response = await fetch('https://api.imgbb.com/1/upload?key=c0573513fc59435a9596c1e20934162b', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Hitilafu katika kupakia picha');
        }
        
        const data = await response.json();
        return data.data.url;
    } catch (error) {
        // Fallback to a placeholder service if ImgBB fails
        console.warn('ImgBB upload failed, using placeholder:', error);
        return `https://picsum.photos/300/200?random=${Date.now()}`;
    }
}

// Authentication
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const phone = document.getElementById('loginPhone').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        // Firebase doesn't support phone auth directly, so we'll use email format
        const email = phone.replace('+', '').replace(/\D/g, '') + '@marketplace.com';
        await auth.signInWithEmailAndPassword(email, password);
        closeModal('loginModal');
        showMessage('Umeingia kikamilifu!', 'success');
    } catch (error) {
        showMessage('Hitilafu katika kuingia: ' + error.message, 'error');
    }
});

document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const phone = document.getElementById('registerPhone').value;
    const location = document.getElementById('userLocation').value;
    const userType = document.getElementById('userType').value;
    const password = document.getElementById('registerPassword').value;
    
    try {
        // Create email format from phone number
        const email = phone.replace('+', '').replace(/\D/g, '') + '@marketplace.com';
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        
        // Save user data to Firestore
        await db.collection('users').doc(userCredential.user.uid).set({
            firstName,
            lastName,
            phone,
            location,
            userType,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        closeModal('registerModal');
        showMessage('Akaunti imetengenezwa kikamilifu!', 'success');
    } catch (error) {
        showMessage('Hitilafu katika usajili: ' + error.message, 'error');
    }
});

// Add Product
document.getElementById('addProductForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    
    const imageFile = document.getElementById('productImage').files[0];
    const name = document.getElementById('productName').value;
    const description = document.getElementById('productDescription').value;
    const price = parseFloat(document.getElementById('productPrice').value);
    const category = document.getElementById('productCategory').value;
    const stock = parseInt(document.getElementById('productStock').value);
    
    try {
        // Upload image to CDN
        const imageUrl = await uploadImageToCDN(imageFile);
        
        // Save product data
        await db.collection('products').add({
            name,
            description,
            price,
            category,
            stock,
            imageUrl,
            sellerId: currentUser.uid,
            sellerLocation: currentUser.location,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        closeModal('addProductModal');
        document.getElementById('addProductForm').reset();
        showMessage('Bidhaa imeongezwa kikamilifu!', 'success');
        loadMyProducts();
    } catch (error) {
        showMessage('Hitilafu katika kuongeza bidhaa: ' + error.message, 'error');
    }
});

// Load Products
async function loadProducts() {
    try {
        const snapshot = await db.collection('products').orderBy('createdAt', 'desc').get();
        allProducts = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        displayProducts(allProducts);
    } catch (error) {
        document.getElementById('productsGrid').innerHTML = `<div class="error">Hitilafu katika kupakia bidhaa: ${error.message}</div>`;
    }
}

// Display Products
// Update the displayProducts function
function displayProducts(products) {
    const grid = document.getElementById('productsGrid');
    
    if (products.length === 0) {
        grid.innerHTML = '<div class="no-products">Hakuna bidhaa zilizopatikana</div>';
        return;
    }
    
    grid.innerHTML = products.map(product => {
        // Prepare WhatsApp message
        const whatsappMessage = `Habari! Nimependa bidhaa yako "${product.name}" kwa bei ya TSh ${product.price.toLocaleString()} kwenye Muganza Marketplace. Naweza kupata maelezo zaidi?`;
        const whatsappUrl = `https://wa.me/${product.sellerPhone ? product.sellerPhone.replace(/\D/g, '') : '255740107466'}?text=${encodeURIComponent(whatsappMessage)}`;
        
        return `
            <div class="product-card">
                <div class="card-content" onclick="showProductDetails('${product.id}')">
                    <img src="${product.imageUrl || 'https://via.placeholder.com/300'}" alt="${product.name}" class="product-image">
                    ${product.stock <= 0 ? '<div class="out-of-stock-badge">Imekwisha</div>' : ''}
                    <div class="product-info">
                        <div class="product-title">${product.name}</div>
                        <div class="product-price">TSH ${product.price.toLocaleString()}</div>
                        <div class="product-location">📍 ${product.sellerLocation || 'Eneo haijajazwa'}</div>
                        <div class="product-description">${product.description.substring(0, 60)}${product.description.length > 60 ? '...' : ''}</div>
                    </div>
                </div>
                
                <div class="product-contact-buttons">
                    <a href="${whatsappUrl}" class="whatsapp-button" target="_blank" onclick="event.stopPropagation(); trackWhatsAppClick('${product.id}')">
                        <i class="fab fa-whatsapp"></i> WhatsApp
                    </a>
                    <a href="tel:${product.sellerPhone || '0740107466'}" class="call-button" onclick="event.stopPropagation(); trackCallClick('${product.id}')">
                        <i class="fas fa-phone"></i> Piga
                    </a>
                </div>
            </div>
        `;
    }).join('');
}

// Search and Filter
document.getElementById('searchInput').addEventListener('input', filterProducts);
document.getElementById('categoryFilter').addEventListener('change', filterProducts);
document.getElementById('locationFilter').addEventListener('change', filterProducts);

function filterProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const categoryFilter = document.getElementById('categoryFilter').value;
    const locationFilter = document.getElementById('locationFilter').value;
    
    const filteredProducts = allProducts.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                            product.description.toLowerCase().includes(searchTerm);
        const matchesCategory = !categoryFilter || product.category === categoryFilter;
        const matchesLocation = !locationFilter || product.sellerLocation === locationFilter;
        
        return matchesSearch && matchesCategory && matchesLocation;
    });
    
    displayProducts(filteredProducts);
}



// Show Product Details Page
async function showProductDetails(productId) {
    // First scroll to top
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });

    // Show loading animation immediately
    document.getElementById('productDetailsContent').innerHTML = `
        <div class="wave-dots">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;

    // Show the details section
    showSection('productDetailsSection');

    // Wait 1 second before loading actual content
    await new Promise(resolve => setTimeout(resolve, 1000));

    try {
        // Find the selected product
        const product = allProducts.find(p => p.id === productId);
        if (!product) {
            throw new Error('Bidhaa haikupatikana');
        }

        // Get seller info
        const sellerDoc = await db.collection('users').doc(product.sellerId).get();
        const seller = sellerDoc.exists ? sellerDoc.data() : null;

        // Prepare WhatsApp message with complete product details
        const whatsappMessage = `Habari! Nimependa bidhaa yako kwenye Muganza Marketplace:\n\n*${product.name}*\n\n*Maelezo:* ${product.description}\n\n*Bei:* TSh ${product.price.toLocaleString()}\n\n*Idadi iliyopo:* ${product.stock}\n\n*Eneo:* ${product.sellerLocation}\n\nNaweza kupata maelezo zaidi?`;
        const whatsappNumber = seller ? seller.phone.replace(/\D/g, '') : '255740107466';
        const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`;

        // Prepare SMS message (for basic phones)
        const smsMessage = `Nipatie maelezo zaidi ya ${product.name} (TSh ${product.price.toLocaleString()})`;
        const smsUrl = `sms:${seller ? seller.phone : '+255740107466'}?body=${encodeURIComponent(smsMessage)}`;

        // Display product details
        document.getElementById('productDetailsContent').innerHTML = `
            <div class="product-detail-container">
                <div class="product-image-container">
                    <img src="${product.imageUrl}" alt="${product.name}" class="product-detail-image" id="productMainImage">
                    ${product.stock <= 0 ? '<div class="out-of-stock">Imekwisha</div>' : ''}
                    
                    <!-- Image sharing for WhatsApp -->
                    <div class="share-buttons">
                        <a href="${whatsappUrl}" class="btn whatsapp-btn share-btn" target="_blank">
                            <i class="fab fa-whatsapp"></i> Tuma kwa WhatsApp
                        </a>
                        <a href="${smsUrl}" class="btn sms-btn share-btn">
                            <i class="fas fa-sms"></i> Tuma SMS
                        </a>
                        <a href="tel:${seller ? seller.phone : '0740107466'}" class="btn call-btn share-btn">
                            <i class="fas fa-phone"></i> Piga Simu
                        </a>
                    </div>
                </div>
                <div class="product-info-container">
                    <h1 class="product-title">${product.name}</h1>
                    <div class="product-price">TSH ${product.price.toLocaleString()}</div>

                    <div class="product-meta">
                        <div class="meta-item">
                            <span class="meta-label">Aina:</span>
                            <span class="meta-value">${getCategoryName(product.category)}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Idadi:</span>
                            <span class="meta-value ${product.stock <= 0 ? 'text-danger' : ''}">
                                ${product.stock <= 0 ? 'Imekwisha' : product.stock}
                            </span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Eneo:</span>
                            <span class="meta-value">${product.sellerLocation}</span>
                        </div>
                    </div>

                    <div class="product-description">
                        <h3>Maelezo</h3>
                        <p>${product.description}</p>
                    </div>

                    ${seller ? `
                    <div class="seller-info">
                        <h3>Taarifa za Muuzaji</h3>
                        <p><strong>Jina:</strong> ${seller.firstName} ${seller.lastName}</p>
                        <p><strong>Simu:</strong> <a href="tel:${seller.phone}">${seller.phone}</a></p>
                        <p><strong>Eneo:</strong> ${seller.location || 'Haijajazwa'}</p>
                    </div>
                    ` : ''}

                    <div class="quick-contact">
                        <h3>Shughulikia Haraka</h3>
                        <div class="contact-buttons">
                            <a href="${whatsappUrl}" class="btn whatsapp-btn" target="_blank" onclick="trackWhatsAppClick('${productId}')">
                                <i class="fab fa-whatsapp"></i> WhatsApp Muuzaji
                            </a>
                            <a href="tel:${seller ? seller.phone : '0740107466'}" class="btn call-btn" onclick="trackCallClick('${productId}')">
                                <i class="fas fa-phone"></i> Piga Simu
                            </a>
                            <button class="btn email-btn" onclick="shareProduct('${productId}')">
                                <i class="fas fa-envelope"></i> Tuma Barua pepe
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Related Products Section -->
            <div class="related-products-section">
                <h3>Bidhaa Zinazohusiana</h3>
                <div id="relatedProducts" class="products-grid"></div>
            </div>
        `;

        // Show related products (excluding current product)
        const relatedProducts = allProducts.filter(p => 
            p.id !== productId && 
            (p.category === product.category || p.sellerLocation === product.sellerLocation)
        ).slice(0, 4);
        
        displayRelatedProducts(relatedProducts);

    } catch (error) {
        document.getElementById('productDetailsContent').innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>${error.message}</p>
                <button class="btn btn-secondary" onclick="showSection('products')">
                    <i class="fas fa-arrow-left"></i> Rudi kwenye orodha ya bidhaa
                </button>
            </div>
        `;
        document.getElementById('relatedProducts').innerHTML = '';
    }
}

// Tracking functions for analytics
function trackWhatsAppClick(productId) {
    // Implement tracking for WhatsApp clicks
    console.log('WhatsApp clicked for product:', productId);
    // You can add Firebase Analytics or other tracking here
}

function trackCallClick(productId) {
    // Implement tracking for call clicks
    console.log('Call clicked for product:', productId);
    // You can add Firebase Analytics or other tracking here
}

// Share product via email
function shareProduct(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;
    
    const subject = `Bidhaa ya ${product.name} - Muganza Marketplace`;
    const body = `Jambo!\n\nNimekutafuta kwa bidhaa hii kwenye Muganza Marketplace:\n\n*Jina:* ${product.name}\n*Maelezo:* ${product.description}\n*Bei:* TSh ${product.price.toLocaleString()}\n*Eneo:* ${product.sellerLocation}\n\nPiga simu kwa: ${product.sellerPhone || '0740107466'}\n\n${product.imageUrl ? `Picha ya bidhaa: ${product.imageUrl}` : ''}`;
    
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}




// Display related products
function displayRelatedProducts(products) {
    const grid = document.getElementById('relatedProducts');
    
    if (products.length === 0) {
        grid.innerHTML = '<div class="loading">Hakuna bidhaa zingine zilizopatikana</div>';
        return;
    }
    
    grid.innerHTML = products.map(product => `
        <div class="product-card fade-in" onclick="showProductDetails('${product.id}')">
            <img src="${product.imageUrl}" alt="${product.name}" class="product-image">
            <div class="product-info">
                <div class="product-title">${product.name}</div>
                <div class="product-price">TSH ${product.price.toLocaleString()}</div>
                <div class="product-location">📍 ${product.sellerLocation}</div>
            </div>
        </div>
    `).join('');
}

// Order Product
async function orderProduct(productId) {
    if (!currentUser) {
        showMessage('Unahitaji kuingia kwanza!', 'error');
        return;
    }
    
    try {
        const product = allProducts.find(p => p.id === productId);
        
        await db.collection('orders').add({
            productId,
            productName: product.name,
            productPrice: product.price,
            productImage: product.imageUrl,
            customerId: currentUser.uid,
            sellerId: product.sellerId,
            status: 'pending',
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        // Update stock
        await db.collection('products').doc(productId).update({
            stock: firebase.firestore.FieldValue.increment(-1)
        });
        
        closeModal('productModal');
        showMessage('Agizo limepokelewa! Muuzaji atawasiliana nawe.', 'success');
    } catch (error) {
        showMessage('Hitilafu katika kuagiza: ' + error.message, 'error');
    }
}

// Helper functions
function getCategoryName(category) {
    const categories = {
        'electronics': 'Elektroniki',
        'fashion': 'Nguo na Mavazi',
        'home': 'Vifaa vya Nyumbani',
        'food': 'Chakula',
        'books': 'Vitabu',
        'other': 'Nyingine'
    };
    return categories[category] || category;
}

// Load My Products (for sellers)
async function loadMyProducts() {
    if (!currentUser || currentUser.userType !== 'seller') return;
    
    try {
        const snapshot = await db.collection('products')
            .where('sellerId', '==', currentUser.uid)
            .orderBy('createdAt', 'desc')
            .get();
        
        const myProducts = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        
        const grid = document.getElementById('myProducts');
        
        if (myProducts.length === 0) {
            grid.innerHTML = '<div class="loading">Hujaweka bidhaa yoyote bado</div>';
            return;
        }
        
        grid.innerHTML = myProducts.map(product => `
            <div class="product-card fade-in">
                <img src="${product.imageUrl}" alt="${product.name}" class="product-image">
                <div class="product-info">
                    <div class="product-title">${product.name}</div>
                    <div class="product-price">TSH ${product.price.toLocaleString()}</div>
                    <div style="color: #666; font-size: 14px;">Idadi: ${product.stock}</div>
                    <div style="color: #666; font-size: 14px; margin-bottom: 10px;">${product.description.substring(0, 80)}...</div>
                    <button class="btn btn-secondary" onclick="editProduct('${product.id}')" style="width: 100%; margin-bottom: 10px;">
                        Hariri
                    </button>
                    <button class="btn" onclick="deleteProduct('${product.id}')" style="width: 100%; background: #ff6b6b; color: white;">
                        Futa
                    </button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        document.getElementById('myProducts').innerHTML = `<div class="error">Hitilafu: ${error.message}</div>`;
    }
}

// Load My Orders (for customers)
async function loadMyOrders() {
    if (!currentUser || currentUser.userType !== 'customer') return;
    
    try {
        const snapshot = await db.collection('orders')
            .where('customerId', '==', currentUser.uid)
            .orderBy('createdAt', 'desc')
            .get();
        
        const myOrders = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        
        const ordersDiv = document.getElementById('myOrders');
        
        if (myOrders.length === 0) {
            ordersDiv.innerHTML = '<div class="loading">Hujaweka agizo lolote bado</div>';
            return;
        }
        
        ordersDiv.innerHTML = myOrders.map(order => `
            <div class="card" style="margin-bottom: 15px;">
                <div style="display: flex; gap: 15px; align-items: center;">
                    <img src="${order.productImage}" alt="${order.productName}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 10px;">
                    <div style="flex: 1;">
                        <div style="font-weight: bold; margin-bottom: 5px;">${order.productName}</div>
                        <div style="color: #667eea; font-weight: bold; margin-bottom: 5px;">TSH ${order.productPrice.toLocaleString()}</div>
                        <div style="color: #666; font-size: 14px;">
                            Hali: <span style="color: ${order.status === 'pending' ? '#ff9800' : order.status === 'confirmed' ? '#4caf50' : '#f44336'}">
                                ${getStatusText(order.status)}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (error) {
        document.getElementById('myOrders').innerHTML = `<div class="error">Hitilafu: ${error.message}</div>`;
    }
}

// Get status text in Swahili
function getStatusText(status) {
    const statusTexts = {
        'pending': 'Inasubiri',
        'confirmed': 'Imethibitishwa',
        'delivered': 'Imefikishwa',
        'cancelled': 'Imeghairiwa'
    };
    return statusTexts[status] || status;
}

// Delete Product
async function deleteProduct(productId) {
    if (!confirm('Una uhakika unataka kufuta bidhaa hii?')) return;
    
    try {
        await db.collection('products').doc(productId).delete();
        showMessage('Bidhaa imefutwa kikamilifu!', 'success');
        loadMyProducts();
    } catch (error) {
        showMessage('Hitilafu katika kufuta bidhaa: ' + error.message, 'error');
    }
}

// Edit Product (simplified - just show alert for now)
function editProduct(productId) {
    showMessage('Kipengele cha kuhariri kitakuja hivi karibuni!', 'success');
}

// Show message
function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = type;
    messageDiv.textContent = message;
    messageDiv.style.position = 'fixed';
    messageDiv.style.top = '20px';
    messageDiv.style.right = '20px';
    messageDiv.style.zIndex = '10000';
    messageDiv.style.padding = '15px 20px';
    messageDiv.style.borderRadius = '10px';
    messageDiv.style.minWidth = '250px';
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

// Logout
function logout() {
    auth.signOut();
}

// Auth state observer
auth.onAuthStateChanged(async (user) => {
    if (user) {
        // User is signed in
        const userDoc = await db.collection('users').doc(user.uid).get();
        currentUser = {
            uid: user.uid,
            ...userDoc.data()
        };
        
        // Update UI
        document.getElementById('userInfo').style.display = 'block';
        document.getElementById('userDetails').innerHTML = `
            <strong>Karibu, ${currentUser.firstName} ${currentUser.lastName}</strong><br>
            <small>Aina ya Akaunti: ${currentUser.userType === 'seller' ? 'Muuzaji' : 'Mteja'} | Eneo: ${currentUser.location}</small>
        `;
        
        // Show/hide buttons based on user type
        document.getElementById('logoutBtn').style.display = 'inline-block';
        document.querySelector('button[onclick="showLogin()"]').style.display = 'none';
        document.querySelector('button[onclick="showRegister()"]').style.display = 'none';
        
        // Add dashboard links
        const navButtons = document.querySelector('.nav-buttons');
        if (currentUser.userType === 'seller') {
            if (!document.getElementById('sellerDashboardBtn')) {
                const sellerBtn = document.createElement('button');
                sellerBtn.id = 'sellerDashboardBtn';
                sellerBtn.className = 'btn btn-secondary';
                sellerBtn.textContent = 'Dashibodi';
                sellerBtn.onclick = () => {
                    showSection('sellerDashboard');
                    loadMyProducts();
                };
                navButtons.insertBefore(sellerBtn, document.getElementById('logoutBtn'));
            }
        } else if (currentUser.userType === 'customer') {
            if (!document.getElementById('customerDashboardBtn')) {
                const customerBtn = document.createElement('button');
                customerBtn.id = 'customerDashboardBtn';
                customerBtn.className = 'btn btn-secondary';
                customerBtn.textContent = 'Maagizo';
                customerBtn.onclick = () => {
                    showSection('customerDashboard');
                    loadMyOrders();
                };
                navButtons.insertBefore(customerBtn, document.getElementById('logoutBtn'));
            }
        }
    } else {
        // User is signed out
        currentUser = null;
        document.getElementById('userInfo').style.display = 'none';
        document.getElementById('logoutBtn').style.display = 'none';
        document.querySelector('button[onclick="showLogin()"]').style.display = 'inline-block';
        document.querySelector('button[onclick="showRegister()"]').style.display = 'inline-block';
        
        // Remove dashboard buttons
        const sellerBtn = document.getElementById('sellerDashboardBtn');
        const customerBtn = document.getElementById('customerDashboardBtn');
        if (sellerBtn) sellerBtn.remove();
        if (customerBtn) customerBtn.remove();
        
        showSection('home');
    }
});

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    loadProducts();
});


// Add this at the end of your JavaScript
function addFloatingWhatsAppButton() {
    const floatBtn = document.createElement('div');
    floatBtn.innerHTML = `
        <a href="https://wa.me/255740107466" class="float-whatsapp" target="_blank">
            <i class="fab fa-whatsapp"></i>
        </a>
    `;
    document.body.appendChild(floatBtn);
    
    // Add CSS for the floating button
    const style = document.createElement('style');
    style.textContent = `
        .float-whatsapp {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 40px;
            right: 40px;
            background-color: #25d366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 30px;
            box-shadow: 2px 2px 3px #999;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
    `;
    document.head.appendChild(style);
}

// Call this function when DOM is loaded
document.addEventListener('DOMContentLoaded', addFloatingWhatsAppButton);


// Add this function to your JavaScript
function showLoading() {
    const loader = document.createElement('div');
    loader.id = 'fullscreen-loader';
    loader.innerHTML = `
        <div class="spinner"></div>
    `;
    document.body.appendChild(loader);
    
    // Add CSS for the loader
    const style = document.createElement('style');
    style.textContent = `
        #fullscreen-loader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        
        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #3498db;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);
    
    return {
        hide: () => loader.remove()
    };
}

// Example usage:
// const loader = showLoading();
// loader.hide();



function addBackToTopButton() {
    const backToTopBtn = document.createElement('button');
    backToTopBtn.id = 'back-to-top';
    backToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    backToTopBtn.title = 'Back to Top';
    document.body.appendChild(backToTopBtn);
    
    // Add CSS for the button
    const style = document.createElement('style');
    style.textContent = `
        #back-to-top {
            position: fixed;
            bottom: 80px;
            right: 40px;
            width: 50px;
            height: 50px;
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            z-index: 99;
            opacity: 0.7;
            transition: all 0.3s;
        }
        
        #back-to-top:hover {
            opacity: 1;
        }
        
        #back-to-top.show {
            display: flex;
        }
    `;
    document.head.appendChild(style);
    
    // Show/hide button based on scroll position
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            backToTopBtn.classList.add('show');
        } else {
            backToTopBtn.classList.remove('show');
        }
    });
    
    // Scroll to top when clicked
    backToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Call this function when DOM is loaded
document.addEventListener('DOMContentLoaded', addBackToTopButton);