


// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBfx2U6d3EFfDBTdr6VPVXtWsDLElNSPmA",
    authDomain: "biashara-37163.firebaseapp.com",
    projectId: "biashara-37163",
    storageBucket: "biashara-37163.firebasestorage.app",
    messagingSenderId: "94176136097",
    appId: "1:94176136097:web:0b98048c135e3e0f61d9e0",
    measurementId: "G-36M6ZY7SZM"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();

// Global variables
let currentUser = null;
let allProducts = [];

// Show/Hide sections
function showSection(sectionName) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');
    
    if (sectionName === 'products') {
        loadProducts();
    }
}

// Modal functions
function showLogin() {
    document.getElementById('loginModal').style.display = 'block';
}

function showRegister() {
    document.getElementById('registerModal').style.display = 'block';
}

function showAddProduct() {
    document.getElementById('addProductModal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Upload image to CDN
async function uploadImageToCDN(imageFile) {
    const formData = new FormData();
    formData.append('image', imageFile);
    
    try {
        // Using ImgBB free CDN service
        const response = await fetch('https://api.imgbb.com/1/upload?key=c0573513fc59435a9596c1e20934162b', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Hitilafu katika kupakia picha');
        }
        
        const data = await response.json();
        return data.data.url;
    } catch (error) {
        // Fallback to a placeholder service if ImgBB fails
        console.warn('ImgBB upload failed, using placeholder:', error);
        return `https://picsum.photos/300/200?random=${Date.now()}`;
    }
}

// Authentication
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const phone = document.getElementById('loginPhone').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        // Firebase doesn't support phone auth directly, so we'll use email format
        const email = phone.replace('+', '').replace(/\D/g, '') + '@marketplace.com';
        await auth.signInWithEmailAndPassword(email, password);
        closeModal('loginModal');
        showMessage('Umeingia kikamilifu!', 'success');
    } catch (error) {
        showMessage('Hitilafu katika kuingia: ' + error.message, 'error');
    }
});

document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const phone = document.getElementById('registerPhone').value;
    const location = document.getElementById('userLocation').value;
    const userType = document.getElementById('userType').value;
    const password = document.getElementById('registerPassword').value;
    
    try {
        // Create email format from phone number
        const email = phone.replace('+', '').replace(/\D/g, '') + '@marketplace.com';
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        
        // Save user data to Firestore
        await db.collection('users').doc(userCredential.user.uid).set({
            firstName,
            lastName,
            phone,
            location,
            userType,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        closeModal('registerModal');
        showMessage('Akaunti imetengenezwa kikamilifu!', 'success');
    } catch (error) {
        showMessage('Hitilafu katika usajili: ' + error.message, 'error');
    }
});

// Add Product
document.getElementById('addProductForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    
    const imageFile = document.getElementById('productImage').files[0];
    const name = document.getElementById('productName').value;
    const description = document.getElementById('productDescription').value;
    const price = parseFloat(document.getElementById('productPrice').value);
    const category = document.getElementById('productCategory').value;
    const stock = parseInt(document.getElementById('productStock').value);
    
    try {
        // Upload image to CDN
        const imageUrl = await uploadImageToCDN(imageFile);
        
        // Save product data
        await db.collection('products').add({
            name,
            description,
            price,
            category,
            stock,
            imageUrl,
            sellerId: currentUser.uid,
            sellerLocation: currentUser.location,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        closeModal('addProductModal');
        document.getElementById('addProductForm').reset();
        showMessage('Bidhaa imeongezwa kikamilifu!', 'success');
        loadMyProducts();
    } catch (error) {
        showMessage('Hitilafu katika kuongeza bidhaa: ' + error.message, 'error');
    }
});

// Load Products
async function loadProducts() {
    try {
        const snapshot = await db.collection('products').orderBy('createdAt', 'desc').get();
        allProducts = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        displayProducts(allProducts);
    } catch (error) {
        document.getElementById('productsGrid').innerHTML = `<div class="error">Hitilafu katika kupakia bidhaa: ${error.message}</div>`;
    }
}

// Display Products
function displayProducts(products) {
    const grid = document.getElementById('productsGrid');
    
    if (products.length === 0) {
        grid.innerHTML = '<div class="loading">Hakuna bidhaa zilizopatikana</div>';
        return;
    }
    
    grid.innerHTML = products.map(product => `
        <div class="product-card fade-in" onclick="showProductDetails('${product.id}')">
            <img src="${product.imageUrl}" alt="${product.name}" class="product-image">
            <div class="product-info">
                <div class="product-title">${product.name}</div>
                <div class="product-price">TSH ${product.price.toLocaleString()}</div>
                <div class="product-location">📍 ${product.sellerLocation}</div>
                <div style="color: #666; font-size: 14px;">${product.description.substring(0, 100)}...</div>
            </div>
        </div>
    `).join('');
}

// Search and Filter
document.getElementById('searchInput').addEventListener('input', filterProducts);
document.getElementById('categoryFilter').addEventListener('change', filterProducts);
document.getElementById('locationFilter').addEventListener('change', filterProducts);

function filterProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const categoryFilter = document.getElementById('categoryFilter').value;
    const locationFilter = document.getElementById('locationFilter').value;
    
    const filteredProducts = allProducts.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                            product.description.toLowerCase().includes(searchTerm);
        const matchesCategory = !categoryFilter || product.category === categoryFilter;
        const matchesLocation = !locationFilter || product.sellerLocation === locationFilter;
        
        return matchesSearch && matchesCategory && matchesLocation;
    });
    
    displayProducts(filteredProducts);
}

// Show Product Details
async function showProductDetails(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;
    
    // Get seller info
    const sellerDoc = await db.collection('users').doc(product.sellerId).get();
    const seller = sellerDoc.data();
    
    document.getElementById('productDetails').innerHTML = `
        <h2>${product.name}</h2>
        <img src="${product.imageUrl}" alt="${product.name}" style="width: 100%; max-height: 300px; object-fit: cover; border-radius: 10px; margin-bottom: 20px;">
        <div style="font-size: 24px; font-weight: bold; color: #667eea; margin-bottom: 15px;">
            TSH ${product.price.toLocaleString()}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Maelezo:</strong><br>
            ${product.description}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Aina:</strong> ${getCategoryName(product.category)}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Idadi Iliyopo:</strong> ${product.stock}
        </div>
        <div style="margin-bottom: 15px;">
            <strong>Eneo:</strong> ${product.sellerLocation}
        </div>
        <div style="margin-bottom: 20px;">
            <strong>Muuzaji:</strong> ${seller.firstName} ${seller.lastName}<br>
            <strong>Simu:</strong> ${seller.phone}
        </div>
        ${currentUser && currentUser.userType === 'customer' ? `
            <button class="btn btn-primary" onclick="orderProduct('${product.id}')" style="width: 100%;">
                Agiza Bidhaa Hii
            </button>
        ` : ''}
    `;
    
    document.getElementById('productModal').style.display = 'block';
}

// Order Product
async function orderProduct(productId) {
    if (!currentUser) {
        showMessage('Unahitaji kuingia kwanza!', 'error');
        return;
    }
    
    try {
        const product = allProducts.find(p => p.id === productId);
        
        await db.collection('orders').add({
            productId,
            productName: product.name,
            productPrice: product.price,
            productImage: product.imageUrl,
            customerId: currentUser.uid,
            sellerId: product.sellerId,
            status: 'pending',
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        // Update stock
        await db.collection('products').doc(productId).update({
            stock: firebase.firestore.FieldValue.increment(-1)
        });
        
        closeModal('productModal');
        showMessage('Agizo limepokelewa! Muuzaji atawasiliana nawe.', 'success');
    } catch (error) {
        showMessage('Hitilafu katika kuagiza: ' + error.message, 'error');
    }
}

// Helper functions
function getCategoryName(category) {
    const categories = {
        'electronics': 'Elektroniki',
        'fashion': 'Nguo na Mavazi',
        'home': 'Vifaa vya Nyumbani',
        'food': 'Chakula',
        'books': 'Vitabu',
        'other': 'Nyingine'
    };
    return categories[category] || category;
}

// Load My Products (for sellers)
async function loadMyProducts() {
    if (!currentUser || currentUser.userType !== 'seller') return;
    
    try {
        const snapshot = await db.collection('products')
            .where('sellerId', '==', currentUser.uid)
            .orderBy('createdAt', 'desc')
            .get();
        
        const myProducts = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        
        const grid = document.getElementById('myProducts');
        
        if (myProducts.length === 0) {
            grid.innerHTML = '<div class="loading">Hujaweka bidhaa yoyote bado</div>';
            return;
        }
        
        grid.innerHTML = myProducts.map(product => `
            <div class="product-card fade-in">
                <img src="${product.imageUrl}" alt="${product.name}" class="product-image">
                <div class="product-info">
                    <div class="product-title">${product.name}</div>
                    <div class="product-price">TSH ${product.price.toLocaleString()}</div>
                    <div style="color: #666; font-size: 14px;">Idadi: ${product.stock}</div>
                    <div style="color: #666; font-size: 14px; margin-bottom: 10px;">${product.description.substring(0, 80)}...</div>
                    <button class="btn btn-secondary" onclick="editProduct('${product.id}')" style="width: 100%; margin-bottom: 10px;">
                        Hariri
                    </button>
                    <button class="btn" onclick="deleteProduct('${product.id}')" style="width: 100%; background: #ff6b6b; color: white;">
                        Futa
                    </button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        document.getElementById('myProducts').innerHTML = `<div class="error">Hitilafu: ${error.message}</div>`;
    }
}

// Load My Orders (for customers)
async function loadMyOrders() {
    if (!currentUser || currentUser.userType !== 'customer') return;
    
    try {
        const snapshot = await db.collection('orders')
            .where('customerId', '==', currentUser.uid)
            .orderBy('createdAt', 'desc')
            .get();
        
        const myOrders = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        
        const ordersDiv = document.getElementById('myOrders');
        
        if (myOrders.length === 0) {
            ordersDiv.innerHTML = '<div class="loading">Hujaweka agizo lolote bado</div>';
            return;
        }
        
        ordersDiv.innerHTML = myOrders.map(order => `
            <div class="card" style="margin-bottom: 15px;">
                <div style="display: flex; gap: 15px; align-items: center;">
                    <img src="${order.productImage}" alt="${order.productName}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 10px;">
                    <div style="flex: 1;">
                        <div style="font-weight: bold; margin-bottom: 5px;">${order.productName}</div>
                        <div style="color: #667eea; font-weight: bold; margin-bottom: 5px;">TSH ${order.productPrice.toLocaleString()}</div>
                        <div style="color: #666; font-size: 14px;">
                            Hali: <span style="color: ${order.status === 'pending' ? '#ff9800' : order.status === 'confirmed' ? '#4caf50' : '#f44336'}">
                                ${getStatusText(order.status)}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (error) {
        document.getElementById('myOrders').innerHTML = `<div class="error">Hitilafu: ${error.message}</div>`;
    }
}

// Get status text in Swahili
function getStatusText(status) {
    const statusTexts = {
        'pending': 'Inasubiri',
        'confirmed': 'Imethibitishwa',
        'delivered': 'Imefikishwa',
        'cancelled': 'Imeghairiwa'
    };
    return statusTexts[status] || status;
}

// Delete Product
async function deleteProduct(productId) {
    if (!confirm('Una uhakika unataka kufuta bidhaa hii?')) return;
    
    try {
        await db.collection('products').doc(productId).delete();
        showMessage('Bidhaa imefutwa kikamilifu!', 'success');
        loadMyProducts();
    } catch (error) {
        showMessage('Hitilafu katika kufuta bidhaa: ' + error.message, 'error');
    }
}

// Edit Product (simplified - just show alert for now)
function editProduct(productId) {
    showMessage('Kipengele cha kuhariri kitakuja hivi karibuni!', 'success');
}

// Show message
function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = type;
    messageDiv.textContent = message;
    messageDiv.style.position = 'fixed';
    messageDiv.style.top = '20px';
    messageDiv.style.right = '20px';
    messageDiv.style.zIndex = '10000';
    messageDiv.style.padding = '15px 20px';
    messageDiv.style.borderRadius = '10px';
    messageDiv.style.minWidth = '250px';
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

// Logout
function logout() {
    auth.signOut();
}

// Auth state observer
auth.onAuthStateChanged(async (user) => {
    if (user) {
        // User is signed in
        const userDoc = await db.collection('users').doc(user.uid).get();
        currentUser = {
            uid: user.uid,
            ...userDoc.data()
        };
        
        // Update UI
        document.getElementById('userInfo').style.display = 'block';
        document.getElementById('userDetails').innerHTML = `
            <strong>Karibu, ${currentUser.firstName} ${currentUser.lastName}</strong><br>
            <small>Aina ya Akaunti: ${currentUser.userType === 'seller' ? 'Muuzaji' : 'Mteja'} | Eneo: ${currentUser.location}</small>
        `;
        
        // Show/hide buttons based on user type
        document.getElementById('logoutBtn').style.display = 'inline-block';
        document.querySelector('button[onclick="showLogin()"]').style.display = 'none';
        document.querySelector('button[onclick="showRegister()"]').style.display = 'none';
        
        // Add dashboard links
        const navButtons = document.querySelector('.nav-buttons');
        if (currentUser.userType === 'seller') {
            if (!document.getElementById('sellerDashboardBtn')) {
                const sellerBtn = document.createElement('button');
                sellerBtn.id = 'sellerDashboardBtn';
                sellerBtn.className = 'btn btn-secondary';
                sellerBtn.textContent = 'Dashibodi';
                sellerBtn.onclick = () => {
                    showSection('sellerDashboard');
                    loadMyProducts();
                };
                navButtons.insertBefore(sellerBtn, document.getElementById('logoutBtn'));
            }
        } else if (currentUser.userType === 'customer') {
            if (!document.getElementById('customerDashboardBtn')) {
                const customerBtn = document.createElement('button');
                customerBtn.id = 'customerDashboardBtn';
                customerBtn.className = 'btn btn-secondary';
                customerBtn.textContent = 'Maagizo';
                customerBtn.onclick = () => {
                    showSection('customerDashboard');
                    loadMyOrders();
                };
                navButtons.insertBefore(customerBtn, document.getElementById('logoutBtn'));
            }
        }
    } else {
        // User is signed out
        currentUser = null;
        document.getElementById('userInfo').style.display = 'none';
        document.getElementById('logoutBtn').style.display = 'none';
        document.querySelector('button[onclick="showLogin()"]').style.display = 'inline-block';
        document.querySelector('button[onclick="showRegister()"]').style.display = 'inline-block';
        
        // Remove dashboard buttons
        const sellerBtn = document.getElementById('sellerDashboardBtn');
        const customerBtn = document.getElementById('customerDashboardBtn');
        if (sellerBtn) sellerBtn.remove();
        if (customerBtn) customerBtn.remove();
        
        showSection('home');
    }
});

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    loadProducts();
});